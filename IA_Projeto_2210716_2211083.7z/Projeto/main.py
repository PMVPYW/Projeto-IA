
from gui import Window

if __name__ == '__main__':
    gui = Window()
    gui.mainloop()
