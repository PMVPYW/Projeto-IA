

class ExperimentEvent:

    def __init__(self, experiment: "Experiment"):
        self.experiment = experiment
